FM-1 Ear Trainer recovery files. Back up your own device first.
See BOOT-SAFETY.md and tools/fm1_recover.py --help. Python source needs PyUSB/libusb for USB access.
Offline validation: python3 tools/fm1_recover.py build/melodee.fwsc --check
Recovery source is included; no device-specific backup is supplied.
